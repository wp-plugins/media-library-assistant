<?php
/**
 * Adds Polylang support to MLA, hooking the filters provided by the MLA_List_Table class
 *
 * @package MLA Polylang Support
 * @version 1.07
 */

/*
Plugin Name: MLA Polylang Support
Plugin URI: http://fairtradejudaica.org/media-library-assistant-a-wordpress-plugin/
Description: Adds Polylang support to MLA, hooking the filters provided by the MLA_List_Table class
Author: David Lingren
Version: 1.07
Author URI: http://fairtradejudaica.org/our-story/staff/

Copyright 2014 - 2015 David Lingren

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You can get a copy of the GNU General Public License by writing to the
	Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110, USA
*/

/**
 * Class MLA Polylang Support hooks all of the filters provided by the MLA_List_Table class
 *
 * Call it anything you want, but give it an unlikely and hopefully unique name. Hiding everything
 * else inside a class means this is the only name you have to worry about.
 *
 * @package MLA Polylang Support
 * @since 1.00
 */
class MLAPolylangSupport {
	/**
	 * Current version number
	 *
	 * @since 1.01
	 *
	 * @var	string
	 */
	const MLA_PLL_CURRENT_VERSION = '1.07';

	/**
	 * Uniquely identifies the nonce
	 *
	 * @since 1.01
	 *
	 * @var	string
	 */
	const MLA_PLL_NONCE = 'mla_pll_admin';

	/**
	 * Uniquely identifies the Quick Translate action
	 *
	 * @since 1.01
	 *
	 * @var	string
	 */
	const MLA_PLL_QUICK_TRANSLATE = 'mla-polylang-quick-translate';

	/**
	 * Initialization function, similar to __construct()
	 *
	 * @since 1.00
	 *
	 * @return	void
	 */
	public static function initialize() {
		/*
		 * The remaining filters are only useful for the admin section; exit in the front-end posts/pages
		 */
		if ( ! is_admin() ) {
			 /*
			  * Defined in /media-library-assistant/includes/class-mla-shortcodes.php
			  */
			add_filter( 'mla_get_terms_query_arguments', 'MLAPolylangSupport::mla_get_terms_query_arguments', 10, 1 );
			add_filter( 'mla_get_terms_clauses', 'MLAPolylangSupport::mla_get_terms_clauses', 10, 1 );
	
			return;
		}

		/*
		 * add_action and add_filter parameters:
		 * $tag - name of the hook you're filtering; defined by [mla_gallery]
		 * $function_to_add - function to be called when [mla_gallery] applies the filter
		 * $priority - default 10; lower runs earlier, higher runs later
		 * $accepted_args - number of arguments your function accepts
		 */

		add_action( 'admin_init', 'MLAPolylangSupport::admin_init' );
 		add_action( 'admin_enqueue_scripts', 'MLAPolylangSupport::admin_enqueue_scripts', 10, 1 );

		// apply_filters in wp-includes/post.php function wp_insert_post
		add_filter( 'edit_attachment', 'MLAPolylangSupport::edit_attachment', 10, 2 );

		 /*
		  * Defined in /wp-admin/includes/class-wp-list-table.php
		  */
		add_filter( 'views_media_page_mla-menu', 'MLAPolylangSupport::views_media_page_mla_menu', 10, 1 );
		//add_filter( 'bulk_actions-media_page_mla-menu', 'MLAPolylangSupport::bulk_actions_media_page_mla_menu', 10, 1 );
		//add_filter( 'months_dropdown_results', 'MLAPolylangSupport::months_dropdown_results', 10, 2 );
		//add_filter( 'mla_entries_per_page', 'MLAPolylangSupport::mla_entries_per_page', 10, 1 );
		//add_filter( 'manage_media_page_mla-menu_sortable_columns', 'MLAPolylangSupport::manage_media_page_mla_menu_sortable_columns', 10, 1 );

		 /*
		  * Defined in /media-library-assistant/includes/class-mla-main.php
		  */
		add_filter( 'mla_list_table_inline_fields', 'MLAPolylangSupport::mla_list_table_inline_fields', 10, 1 );
		add_filter( 'mla_list_table_inline_action', 'MLAPolylangSupport::mla_list_table_inline_action', 10, 2 );
		add_filter( 'mla_list_table_bulk_action_initial_request', 'MLAPolylangSupport::mla_list_table_bulk_action_initial_request', 10, 2 );
		add_filter( 'mla_list_table_bulk_action_item_request', 'MLAPolylangSupport::mla_list_table_bulk_action_item_request', 10, 3 );
		add_filter( 'mla_list_table_bulk_action', 'MLAPolylangSupport::mla_list_table_bulk_action', 10, 3 );
		add_filter( 'mla_list_table_custom_bulk_action', 'MLAPolylangSupport::mla_list_table_custom_bulk_action', 10, 3 );
		//add_filter( 'mla_list_table_single_action', 'MLAPolylangSupport::mla_list_table_single_action', 10, 3 );
		//add_filter( 'mla_list_table_custom_single_action', 'MLAPolylangSupport::mla_list_table_custom_single_action', 10, 3 );
		//add_action( 'mla_list_table_clear_filter_by', 'MLAPolylangSupport::mla_list_table_clear_filter_by' );
		add_filter( 'mla_list_table_new_instance', 'MLAPolylangSupport::mla_list_table_new_instance', 10, 1 );
		add_filter( 'mla_list_table_inline_values', 'MLAPolylangSupport::mla_list_table_inline_values', 10, 1 );
		//add_filter( 'mla_list_table_inline_template', 'MLAPolylangSupport::mla_list_table_inline_template', 10, 1 );
		add_filter( 'mla_list_table_inline_parse', 'MLAPolylangSupport::mla_list_table_inline_parse', 10, 3 );

		 /*
		  * Defined in /media-library-assistant/includes/class-mla-list-table.php
		  */
		add_filter( 'mla_list_table_get_columns', 'MLAPolylangSupport::mla_list_table_get_columns', 10, 1 );
		//add_filter( 'mla_list_table_get_hidden_columns', 'MLAPolylangSupport::mla_list_table_get_hidden_columns', 10, 1 );
		//add_filter( 'mla_list_table_get_sortable_columns', 'MLAPolylangSupport::mla_list_table_get_sortable_columns', 10, 1 );
		add_filter( 'mla_list_table_get_bulk_actions', 'MLAPolylangSupport::mla_list_table_get_bulk_actions', 10, 1 );
		add_filter( 'mla_list_table_column_default', 'MLAPolylangSupport::mla_list_table_column_default', 10, 3 );

		add_filter( 'mla_list_table_submenu_arguments', 'MLAPolylangSupport::mla_list_table_submenu_arguments', 10, 2 );
		
		add_filter( 'mla_list_table_prepare_items_pagination', 'MLAPolylangSupport::mla_list_table_prepare_items_pagination', 10, 2 );
		add_filter( 'mla_list_table_prepare_items_total_items', 'MLAPolylangSupport::mla_list_table_prepare_items_total_items', 10, 2 );
		//add_filter( 'mla_list_table_prepare_items_the_items', 'MLAPolylangSupport::mla_list_table_prepare_items_the_items', 10, 2 );
		//add_action( 'mla_list_table_prepare_items', 'MLAPolylangSupport::mla_list_table_prepare_items', 10, 1 );
		
		add_filter( 'mla_list_table_build_rollover_actions', 'MLAPolylangSupport::mla_list_table_build_rollover_actions', 10, 3 );
		add_filter( 'mla_list_table_build_inline_data', 'MLAPolylangSupport::mla_list_table_build_inline_data', 10, 2 );

		// 'views_upload' is only applied when WPML is active
		//add_filter( 'views_upload', 'MLAPolylangSupport::views_upload', 10, 1 );
	}

	/**
	 * Load the plugin's Ajax handler(s)
	 *
	 * @since 0.20
	 *
	 * @return	void
	 */
	public static function admin_init() {
		//error_log( 'MLAPolylangSupport::admin_init $_REQUEST = ' . var_export( $_REQUEST, true ), 0 );

		if ( ( defined('WP_ADMIN') && WP_ADMIN ) && ( defined('DOING_AJAX') && DOING_AJAX ) ) {
			add_action( 'wp_ajax_' . 'mla-polylang-quick-translate', 'MLAPolylangSupport::quick_translate' );
		}
	}

	/**
	 * Find or create an item translation
	 *
	 * @since 1.04
	 *
	 * @param	integer	item ID
	 * @param	string	Slug of the desired language
	 *
	 * @return	integer	ID of the corresponding item in the desired language
	 */
	private static function _get_translation( $post_id, $new_language ) {
		global $polylang;
		//error_log( 'MLAPolylangSupport::_get_translation $post_id = ' . var_export( $post_id, true ), 0 );
		//error_log( 'MLAPolylangSupport::_get_translation $new_language = ' . var_export( $new_language, true ), 0 );
		
		/*
		 * Get the existing translations, if any
		 */
		$translations = $polylang->model->get_translations( 'post', $post_id );
		if ( ! $translations && $lang = $polylang->model->get_post_language( $post_id ) ) {
			$translations[ $lang->slug ] = $post_id;
		}

		if ( array_key_exists( $new_language, $translations ) ) {
			$new_id = $translations[ $new_language ];
		} else {
			/*
			 * create a new attachment (translate attachment parent if exists)
			 * modeled after /polylang/admin/admin-filters-media.php
			 * function translate_media()
			 */
			$post = get_post( $post_id );
			$post->ID = null; // will force the creation
			$post->post_parent = ( $post->post_parent && $tr_parent = $polylang->model->get_translation( 'post', $post->post_parent, $new_language ) ) ? $tr_parent : 0;
			$new_id = wp_insert_attachment( $post );
			add_post_meta( $new_id, '_wp_attachment_metadata', get_post_meta( $post_id, '_wp_attachment_metadata', true ) );
			add_post_meta( $new_id, '_wp_attached_file', get_post_meta( $post_id, '_wp_attached_file', true ) );
			$polylang->model->set_post_language($new_id, $new_language);
			
			$translations = $polylang->model->get_translations( 'post', $post_id );
			if ( ! $translations && $lang = $polylang->model->get_post_language( $post_id ) )
				$translations[ $lang->slug ] = $post_id;
	
			$translations[ $new_language ] = $new_id;
			$polylang->model->save_translations( 'post', $new_id, $translations );
		} // add new translation
		
		return (integer) $new_id;
	}

	/**
	 * Ajax handler to Quick Translate a single attachment
	 *
	 * @since 1.01
	 *
	 * @return	void	echo HTML <td> innerHTML for updated call or error message, then die()
	 */
	public static function quick_translate() {
		//global $polylang;
		
		//error_log( 'MLAPolylangSupport::quick_translate $_REQUEST = ' . var_export( $_REQUEST, true ), 0 );
		check_ajax_referer( self::MLA_PLL_NONCE, 'nonce' );

		if ( empty( $_REQUEST['post_ID'] ) ) {
			echo __( 'ERROR: No post ID found', 'mla-polylang-support' );
			die();
		} else {
			$post_id = (integer) $_REQUEST['post_ID'];
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_die( __( 'You are not allowed to edit this Attachment.', 'mla-polylang-support' ) );
		}

		/*
		 * Create a new translated attachment object
		 */
		if ( ! empty( $_REQUEST['pll_quick_language'] ) ) {
			$new_id = self::_get_translation( $post_id, $_REQUEST['pll_quick_language'] );
		} else {
			$new_id = $post_id;
		}
		//error_log( 'MLAPolylangSupport::quick_translate $new_id = ' . var_export( $new_id, true ), 0 );
		//error_log( 'MLAPolylangSupport::quick_translate $post_id = ' . var_export( $post_id, true ), 0 );
		 
		$new_item = (object) MLAData::mla_get_attachment_by_id( $new_id );
		
		//	Create an instance of our package class and echo the new HTML
		$MLAListTable = new MLA_List_Table();
		$MLAListTable->single_row( $new_item );
		
		if ( $new_id != $post_id ) {
			$new_item = (object) MLAData::mla_get_attachment_by_id( $post_id );
			$MLAListTable->single_row( $new_item );
		}
		
		die(); // this is required to return a proper result
	}

	/**
	 * Load the plugin's Style Sheet and Javascript files
	 *
	 * @since 1.01
	 *
	 * @param	string	Name of the page being loaded
	 *
	 * @return	void
	 */
	public static function admin_enqueue_scripts( $page_hook ) {
		//error_log( 'MLAPolylangSupport::admin_enqueue_scripts $page_hook = ' . var_export( $page_hook, true ), 0 );
		$suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';
		//error_log( 'MLAPolylangSupport::admin_enqueue_scripts $suffix = ' . var_export( $suffix, true ), 0 );

		if ( 'media_page_mla-menu' != $page_hook ) {
			return;
		}

		wp_register_style( 'mla-polylang-support', plugin_dir_url( __FILE__ ) . 'mla-polylang-support.css', false, self::MLA_PLL_CURRENT_VERSION );
		wp_enqueue_style( 'mla-polylang-support' );

		wp_enqueue_script( 'mla-polylang-support-scripts', plugin_dir_url( __FILE__ ) . "mla-polylang-support-scripts{$suffix}.js", 
			array( 'jquery' ), self::MLA_PLL_CURRENT_VERSION, false );

		// For Quick and Bulk Translate
		$fields = array( 'old_lang', 'inline_lang_choice', 'inline_translations' );

		$script_variables = array(
			'fields' => $fields,
			//'ajaxFailError' => __( 'An ajax.fail error has occurred. Please reload the page and try again.', 'mla-polylang-support' ),
			//'ajaxDoneError' => __( 'An ajax.done error has occurred. Please reload the page and try again.', 'mla-polylang-support' ),
			'error' => __( 'Error while saving the translations.', 'mla-polylang-support' ),
			'ntdelTitle' => __( 'Remove From Bulk Translate', 'mla-polylang-support' ),
			'noTitle' => __( '(no title)', 'mla-polylang-support' ),
			'bulkTitle' => __( 'Bulk Translate items', 'mla-polylang-support' ),
			'addNew' => __( 'Add new', 'mla-polylang-support' ),
			'edit' => __( 'Edit', 'mla-polylang-support' ),
			'comma' => _x( ',', 'tag_delimiter', 'mla-polylang-support' ),
			'ajax_action' => self::MLA_PLL_QUICK_TRANSLATE,
			'ajax_nonce' => wp_create_nonce( self::MLA_PLL_NONCE ) 
		);

		wp_localize_script( 'mla-polylang-support-scripts', 'mla_polylang_support_vars', $script_variables );
	}

	/**
	 * Filters taxonomy updates by language.
	 *
	 * @since 1.06
	 *
	 * @param	integer	ID of the current post
	 */
	public static function edit_attachment( $post_id ) {
		static $already_updating = false;
		
		//error_log( 'MLAPolylangSupport::edit_attachment $post_id = ' . var_export( $post_id, true ), 0 );
		//error_log( 'MLAPolylangSupport::edit_attachment $already_updating = ' . var_export( $already_updating, true ), 0 );
		//error_log( 'MLAPolylangSupport::edit_attachment $_REQUEST = ' . var_export( $_REQUEST, true ), 0 );

		/*
		 * mla_update_single_item eventually calls this action again
		 */
		if ( $already_updating ) {
			return;
		}
		
		/*
		 * The category taxonomy (edit screens) is a special case because 
		 * post_categories_meta_box() changes the input name
		 */
		if ( isset( $_REQUEST['tax_input'] ) ) {
			$taxonomies = $_REQUEST['tax_input'];
		} else {
			$taxonomies = array();
		}

		if ( isset( $_REQUEST['post_category'] ) ) {
			$taxonomies['category'] = $_REQUEST['post_category'];
		}

		if ( ! empty( $taxonomies ) ) {
			self::_build_tax_input( $taxonomies );
			$taxonomies = self::_apply_tax_input( $taxonomies, $post_id );
		}
		
		//error_log( 'MLAPolylangSupport::edit_attachment $taxonomies = ' . var_export( $taxonomies, true ), 0 );
		if ( !empty( $taxonomies ) ) {
			$already_updating = true; // prevent recursion
			MLAData::mla_update_single_item( $post_id, array(), $taxonomies );
			$already_updating = false;
		}
	} // edit_attachment

	/**
	 * PolyMLA custom views for the Media/Assistant submenu
	 *
	 * @since 1.04
	 *
	 * @param	string	The slug for the custom view to evaluate
	 * @param	string	The slug for the current custom view, or ''
	 *
	 * @return	mixed	HTML for link to display the view, false if count = zero
	 */
	private static function _get_view( $view_slug, $current_view ) {
		//error_log( 'MLAPolylangSupport::_get_view $view_slug = ' . var_export( $view_slug, true ), 0 );
		//error_log( 'MLAPolylangSupport::_get_view $current_view = ' . var_export( $current_view, true ), 0 );
		global $wpdb;
		static $posts_per_view = NULL,
			$view_singular = array (),
			$view_plural = array ();
		/*
		 * Calculate the common values once per page load
		 */
		if ( is_null( $posts_per_view ) ) {
			if ( empty( self::$list_table_parameters['total_items'] ) ) {
				self::$list_table_parameters['total_items'] = (integer) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_parent > 0 AND post_type = 'attachment' AND post_status = 'inherit'" );
			}
			
			$posts_per_view = array( 'attached' => self::$list_table_parameters['total_items'] );
			
			$view_singular = array (
				'attached' => __( 'Attached', 'mla-polylang-support' ),
			);
			$view_plural = array (
				'attached' => __( 'Attached', 'mla-polylang-support' ),
			);
		}

		/*
		 * Make sure the slug is in our list and has posts
		 */
		if ( array_key_exists( $view_slug, $posts_per_view ) ) {
			$post_count = $posts_per_view[ $view_slug ];
			$singular = sprintf('%s <span class="count">(%%s)</span>', $view_singular[ $view_slug ] );
			$plural = sprintf('%s <span class="count">(%%s)</span>', $view_plural[ $view_slug ] );
			$nooped_plural = _n_noop( $singular, $plural, 'mla-polylang-support' );
		} else {
			return false;
		}

		if ( $post_count ) {
			$query = array( 'pll_view' => $view_slug );
			$base_url = 'upload.php?page=mla-menu';
			$class = ( $view_slug == $current_view ) ? ' class="current"' : '';
			
			return "<a href='" . add_query_arg( $query, $base_url ) . "'$class>" . sprintf( translate_nooped_plural( $nooped_plural, $post_count, 'mla-polylang-support' ), number_format_i18n( $post_count ) ) . '</a>';
		}

		return false;
	}

	/**
	 * Views for media page MLA Menu
	 *
	 * This filter gives you an opportunity to filter the list of available list table views.
	 *
	 * @since 1.00
	 *
	 * @param	array	$views An array of available list table views.
	 *					format: view_slug => link to the view, with count
	 *
	 * @return	array	updated list table views.
	 */
	public static function views_media_page_mla_menu( $views ) {
		//error_log( 'MLAPolylangSupport::views_media_page_mla_menu $views = ' . var_export( $views, true ), 0 );
		
		if ( isset( $_REQUEST['pll_view'] ) ) {
			switch( $_REQUEST['pll_view'] ) {
				case 'attached':
					$current_view = 'attached';
					break;
				default:
					$current_view = '';
			} // pll_view
		} else {
			$current_view = '';
		}
		
		foreach ( $views as $slug => $view ) {
			// Find/update the current view
			if ( strpos( $view, ' class="current"' ) ) {
				if ( ! empty( $current_view ) ) {
					$views[ $slug ] = str_replace( ' class="current"', '', $view );
				} else {
					$current_view = $slug;
				}
			}
		} // each view

		$value = self::_get_view( 'attached', $current_view );
		if ( $value ) {
			$views['attached'] = $value;
		}
		
		return $views;
	} // views_media_page_mla_menu_filter

	/**
	 * Filter the list table Bulk Actions drop-down
	 *
	 * This filter gives you an opportunity to filter the list table Bulk Actions drop-down.
	 *
	 * @since 1.00
	 *
	 * @param	array	$actions An array of the available bulk actions.
	 *					format: action_slug => Action Label
	 *
	 * @return	array	updated available bulk actions.
	 */
	public static function bulk_actions_media_page_mla_menu( $actions ) {
		//error_log( 'MLAPolylangSupport::bulk_actions_media_page_mla_menu $actions = ' . var_export( $actions, true ), 0 );
		return $actions;
	} // bulk_actions_media_page_mla_menu_filter

	/**
	 * Filter the 'Months' drop-down results
	 *
	 * This filter gives you an opportunity to filter the Months' drop-down.
	 *
	 * @since 1.00
	 *
	 * @param	array	$months    The months drop-down query result objects.
	 *					format: index => array( 'year' => year, 'month' => month )
	 * @param	string	$post_type The post type, e.g., 'attachment'.
	 *
	 * @return	array	updated months query results.
	 */
	public static function months_dropdown_results( $months, $post_type ) {
		//error_log( "MLAPolylangSupport::months_dropdown_results ({$post_type}) \$months = " . var_export( $months[0], true ), 0 );
		return $months;
	} // months_dropdown_results_filter

	/**
	 * Filter the number of items to be displayed on each page of the list table
	 *
	 * This filter gives you an opportunity to filter the number of items to be displayed
	 * on each page of the list table.
	 *
	 * @since 1.00
	 *
	 * @param	integer	$per_page Number of items to be displayed. Default 20.
	 *
	 * @return	integer	updated items to be displayed.
	 */
	public static function mla_entries_per_page( $per_page ) {
		//error_log( 'MLAPolylangSupport::mla_entries_per_page $per_page = ' . var_export( $per_page, true ), 0 );
		return $per_page;
	} // mla_entries_per_page_filter
	
	/**
	 * Filter the list table sortable columns for a specific screen
	 *
	 * This filter gives you an opportunity to filter the list table sortable columns.
	 *
	 * @since 1.00
	 *
	 * @param	array	$sortable_columns	An array of sortable columns.
	 *										Format: 'column_slug' => 'orderby'
	 *										or 'column_slug' => array( 'orderby', true )
	 *
	 * The second format will make the initial sorting order be descending.
	 *
	 * @return	array	updated array of sortable columns.
	 */
	public static function manage_media_page_mla_menu_sortable_columns( $sortable_columns ) {
		//error_log( 'MLAPolylangSupport::manage_media_page_mla_menu_sortable_columns $sortable_columns = ' . var_export( $sortable_columns, true ), 0 );
		return $sortable_columns;
	} // manage_media_page_mla_menu_sortable_columns

	/**
	 * Process an MLA_List_Table inline action, i.e., Quick Edit 
	 *
	 * Process the Language dropdown selection, if changed.
	 *
	 * @since 1.00
	 *
	 * @param	array	$item_content	NULL, to indicate no handler.
	 * @param	integer	$post_id		the affected attachment.
	 *
	 * @return	object	updated $item_content. NULL if no handler, otherwise
	 *					( 'message' => error or status message(s), 'body' => '',
	 *					  'prevent_default' => true to bypass the MLA handler )
	 */
	public static function mla_list_table_inline_action( $item_content, $post_id ) {
		global $polylang;
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_action $item_content = ' . var_export( $item_content, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_action $post_id = ' . var_export( $post_id, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_action $_REQUEST = ' . var_export( $_REQUEST, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_action $polylang = ' . var_export( $polylang, true ), 0 );

		// Language dropdown in Quick Edit area
		if ( isset( $_REQUEST['inline_lang_choice'] ) ) {
			if ( isset( $_REQUEST['old_lang'] ) && $_REQUEST['old_lang'] != $_REQUEST['inline_lang_choice'] ) {
				$post = get_post( $post_id );
				// save_post() does a check_admin_referer() security test
				$_REQUEST['_inline_edit'] = wp_create_nonce( 'inlineeditnonce' );
				$polylang->filters_post->save_post( $post_id, $post, true );
			} // change language
		}
		
		if ( isset( $_REQUEST['tax_input'] ) ) {
			self::_build_tax_input( $_REQUEST['tax_input'] );
			$_REQUEST['tax_input'] = self::_apply_tax_input( $_REQUEST['tax_input'], $post_id );
		}

		return $item_content;
	} // mla_list_table_inline_action

	/**
	 * Taxonmy terms in all languages
	 *
	 * @since 1.06
	 *
	 * @var	array
	 */
	private static $tax_input = array();
	
	/**
	 * Build the $tax_input array
	 *
	 * Takes each term from the $taxonomies parameter and builds an array of
	 * language-specific term_id to term_id/term_name mappings for all languages.
	 *
	 * @since 1.06
	 * @uses MLAPolylangSupport::$tax_input
	 *
	 * @param	array	$taxonomies	'tax_input' request parameter
	 *
	 */
	private static function _build_tax_input( $taxonomies ) {
		global $polylang;
		
		foreach ( $taxonomies as $taxonomy => $terms ) {
			// hierarchical taxonomy => array of term_id values; flat => string
			if ( is_array( $terms ) ) {
				self::$tax_input[ $taxonomy ]['taxonomy_type'] = 'hierarchical';
				foreach( $terms as $term ) {
					if ( 0 == $term ) {
						continue;
					}
					
					$translations = $polylang->model->get_translations( 'term', $term );
					foreach ( $translations as $language => $term_id ) {
						self::$tax_input[ $taxonomy ][ $language ][ $term_id ] = $term_id;
					} // for each language
				} // foreach term
			} else {
				self::$tax_input[ $taxonomy ]['taxonomy_type'] = 'flat';
				/*
				 * Convert names to IDs, get ID translations, convert back to names
				 */
				$term_names = array_map( 'trim', explode( ',', $terms ) );
				foreach ( $term_names as $term_name ) {
					if ( ! empty( $term_name ) ) {
						$term = get_term_by( 'name', $term_name, $taxonomy );
						$translations = $polylang->model->get_translations( 'term', $term->term_id );

						foreach ( $translations as $language => $term_id ) {
							$term = get_term_by( 'id', $term_id, $taxonomy );
							self::$tax_input[ $taxonomy ][ $language ][ $term_id ] = $term->name;
						} // for each language
					} // not empty
				} // foreach name
			}
		} // foreach taxonomy
	} // _build_tax_input

	/**
	 * Filter the $tax_input array to a specific language
	 *
	 * @since 1.06
	 *
	 * @param	array	$taxonomies	'tax_input' request parameter
	 * @param	integer	$post_id ID of the current post
	 *
	 * @return	array	updated $taxonomies
	 */
	private static function _apply_tax_input( $taxonomies, $post_id ) {
		global $polylang;
		
		$post_language = $polylang->model->get_post_language( $post_id );
		$post_language = $post_language->slug;
		
		$translated_taxonomies = array();
		foreach ( $taxonomies as $taxonomy => $terms ) {
			if ( isset( self::$tax_input[ $taxonomy ][ $post_language ] ) ) {
				$terms = self::$tax_input[ $taxonomy ][ $post_language ];
				if ( 'flat' == self::$tax_input[ $taxonomy ]['taxonomy_type'] ) {
					$terms = implode( ',', $terms );
				} else {
					// renumber the keys
					$terms = array_merge( $terms );
				}
				
				$translated_taxonomies[ $taxonomy ] = $terms;
			} // found language
		} // foreach taxonomy 

		return $translated_taxonomies;
	} // _apply_tax_input

	/**
	 * Pre-filter MLA_List_Table bulk action request parameters
	 *
	 * Builds an array of term_id to term_id/term_name maps for taxonomy term updates in any language
	 *
	 * @since 1.06
	 *
	 * @param	array	$request		bulk action request parameters, including ['mla_bulk_action_do_cleanup'].
	 * @param	string	$bulk_action	the requested action.
	 *
	 * @return	object	updated $item_content. NULL if no handler, otherwise
	 *					( 'message' => error or status message(s), 'body' => '',
	 *					  'prevent_default' => true to bypass the MLA handler )
	 */
	public static function mla_list_table_bulk_action_initial_request( $request, $bulk_action ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_bulk_action_initial_request $request = ' . var_export( $request, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_bulk_action_initial_request $bulk_action = ' . var_export( $bulk_action, true ), 0 );

		if ( isset( $request['tax_input'] ) ) {
			self::_build_tax_input( $request['tax_input'] );
		}

		return $request;
	} // mla_list_table_bulk_action_initial_request

	/**
	 * Filter MLA_List_Table bulk action request parameters for each item
	 *
	 * Creates an array of term updates in the specific language of the current item
	 *
	 * @since 1.06
	 *
	 * @param	array	$request		bulk action request parameters, including ['mla_bulk_action_do_cleanup'].
	 * @param	string	$bulk_action	the requested action.
	 * @param	integer	$post_id		the affected attachment.
	 *
	 * @return	array	updated $request
	 */
	public static function mla_list_table_bulk_action_item_request( $request, $bulk_action, $post_id ) {
		global $polylang;

		//error_log( 'MLAPolylangSupport::mla_list_table_bulk_action_item_request $request = ' . var_export( $request, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_bulk_action_item_request $bulk_action = ' . var_export( $bulk_action, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_bulk_action_item_request $post_id = ' . var_export( $post_id, true ), 0 );
		
		if ( isset( $request['tax_input'] ) ) {
			$request['tax_input'] = self::_apply_tax_input( $request['tax_input'], $post_id );
		}
		
		return $request;
	} // mla_list_table_bulk_action_item_request

	/**
	 * Process an MLA_List_Table bulk action
	 *
	 * Sets the new item language from the Language dropdown selection.
	 *
	 * @since 1.00
	 *
	 * @param	array	$item_content	NULL, to indicate no handler.
	 * @param	string	$bulk_action	the requested action.
	 * @param	integer	$post_id		the affected attachment.
	 *
	 * @return	object	updated $item_content. NULL if no handler, otherwise
	 *					( 'message' => error or status message(s), 'body' => '',
	 *					  'prevent_default' => true to bypass the MLA handler )
	 */
	public static function mla_list_table_bulk_action( $item_content, $bulk_action, $post_id ) {
		global $polylang;
		//error_log( 'MLAPolylangSupport::mla_list_table_bulk_action $item_content = ' . var_export( $item_content, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_bulk_action $bulk_action = ' . var_export( $bulk_action, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_bulk_action $post_id = ' . var_export( $post_id, true ), 0 );

		// Language dropdown in Bulk Edit area
		if ( isset( $_POST['inline_lang_choice'] ) ) {
			$post = get_post( $post_id );
			// save_post() does a check_admin_referer() security test
			$_REQUEST['_wpnonce'] = wp_create_nonce( 'bulk-posts' );
			$_REQUEST['bulk_edit'] = 'Update';
			$polylang->filters_post->save_post( $post_id, $post, true );
		
			if ( $_REQUEST['inline_lang_choice'] != -1 ) {
				$item_content = array( 'message' => "Item {$post_id}, language updated." );
			}
		}

		return $item_content;
	} // mla_list_table_bulk_action

	/**
	 * Items returned by custom bulk action(s)
	 *
	 * @since 1.04
	 *
	 * @var	array
	 */
	private static $bulk_action_includes = array();
	
	/**
	 * Process an MLA_List_Table custom bulk action
	 *
	 * Creates new items from the "Bulk Translate" list.
	 *
	 * @since 1.00
	 *
	 * @param	array	$item_content	NULL, to indicate no handler.
	 * @param	string	$bulk_action	the requested action.
	 * @param	integer	$post_id		the affected attachment.
	 *
	 * @return	object	updated $item_content. NULL if no handler, otherwise
	 *					( 'message' => error or status message(s), 'body' => '' )
	 */
	public static function mla_list_table_custom_bulk_action( $item_content, $bulk_action, $post_id ) {
		global $polylang;
		//error_log( 'MLAPolylangSupport::mla_list_table_custom_bulk_action $_REQUEST = ' . var_export( $_REQUEST, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_custom_bulk_action $item_content = ' . var_export( $item_content, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_custom_bulk_action $bulk_action = ' . var_export( $bulk_action, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_custom_bulk_action $post_id = ' . var_export( $post_id, true ), 0 );

		if ( 'pll-translate' == $bulk_action ) {
			$translations = array();
			if ( isset( $_REQUEST['bulk_tr_languages'] ) ) {
				$bulk_tr_languages = $_REQUEST['bulk_tr_languages'];
				
				// Expand All Languages selection
				if ( isset( $bulk_tr_languages['all'] ) ) {
					foreach ($polylang->model->get_languages_list() as $language) {
						$bulk_tr_languages[ $language->slug ] = 'translate';
					}
					
					unset( $bulk_tr_languages['all'] );
				}
				
				// Process language selection(s)
				foreach( $bulk_tr_languages as $language => $action ) {
					$new_id = self::_get_translation( $post_id, $language );
					$translations[] = $new_id;
				}
			}

			// Clear all the "Filter-by" parameters
			if ( isset( $_REQUEST['bulk_tr_options']['clear_filters'] ) ) {
				unset( $_REQUEST['heading_suffix'] );
				unset( $_REQUEST['parent'] );
				unset( $_REQUEST['author'] );
				unset( $_REQUEST['mla-tax'] );
				unset( $_REQUEST['mla-term'] );
				unset( $_REQUEST['mla-metakey'] );
				unset( $_REQUEST['mla-metavalue'] );
			}

			if ( empty( $translations ) ) {
				$item_content = array( 'message' => "Item {$post_id}, no translations." );
			} else {
				$_REQUEST['heading_suffix'] = __( 'Bulk Translations', 'mla-polylang-support' );
				self::$bulk_action_includes = array_merge( self::$bulk_action_includes, $translations );
				$translations = implode( ',', $translations );
				$item_content = array( 'message' => "Item {$post_id}, translation(s): {$translations}." );
			}
		}

		return $item_content;
	} // mla_list_table_custom_bulk_action

	/**
	 * Process an MLA_List_Table single action
	 *
	 * This filter gives you an opportunity to pre-process an MLA_List_Table page-level
	 * or single-item action, standard or custom, before the MLA handler.
	 *
	 * @since 1.00
	 *
	 * @param	array	$page_content 		NULL, to indicate no handler.
	 * @param	string	$mla_admin_action	the requested action.
	 * @param	integer	$mla_item_ID		zero (0), or the affected attachment.
	 *
	 * @return	object	updated $page_content. NULL if no handler, otherwise
	 *					( 'message' => error or status message(s),
	 *					  'body' => '' or page content in place of the submenu table,
	 *					  'prevent_default' => true to bypass the MLA handler )
	 */
	public static function mla_list_table_single_action( $page_content, $mla_admin_action, $mla_item_ID ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_single_action $page_content = ' . var_export( $page_content, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_single_action $mla_admin_action = ' . var_export( $mla_admin_action, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_single_action $mla_item_ID = ' . var_export( $mla_item_ID, true ), 0 );
		return $page_content;
	} // mla_list_table_single_action

	/**
	 * Process an MLA_List_Table custom single action
	 *
	 * This filter gives you an opportunity to process an MLA_List_Table page-level
	 * or single-item action that MLA does not recognize.
	 *
	 * @since 1.00
	 *
	 * @param	array	$page_content 		NULL, to indicate no handler.
	 * @param	string	$mla_admin_action	the requested action.
	 * @param	integer	$mla_item_ID		zero (0), or the affected attachment.
	 *
	 * @return	object	updated $page_content. NULL if no handler, otherwise
	 *					( 'message' => error or status message(s),
	 *					  'body' => '' or page content in place of the submenu table )
	 */
	public static function mla_list_table_custom_single_action( $page_content, $mla_admin_action, $mla_item_ID ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_custom_single_action $page_content = ' . var_export( $page_content, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_custom_single_action $mla_admin_action = ' . var_export( $mla_admin_action, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_custom_single_action $mla_item_ID = ' . var_export( $mla_item_ID, true ), 0 );
		return $page_content;
	} // mla_list_table_custom_single_action

	/**
	 * Clear the custom "Filter-by" parameters
	 *
	 * This action gives you an opportunity to clear any custom submenu "Filter-by" parameters.
	 *
	 * @since 1.04
	 *
	 * @return	void
	 */
	public static function mla_list_table_clear_filter_by() {
		//error_log( 'MLAPolylangSupport::mla_list_table_clear_filter_by $_REQUEST = ' . var_export( $_REQUEST, true ), 0 );
	} // mla_list_table_clear_filter_by
	
	/**
	 * Extend the MLA_List_Table class
	 *
	 * This filter gives you an opportunity to extend the MLA_List_Table class.
	 *
	 * @since 1.00
	 *
	 * @param	object	$mla_list_table NULL, to indicate no extension/use the base class.
	 *
	 * @return	object	updated mla_list_table object.
	 */
	public static function mla_list_table_new_instance( $mla_list_table ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_new_instance $mla_list_table = ' . var_export( $mla_list_table, true ), 0 );
		return $mla_list_table;
	} // mla_list_table_new_instance
	
	/**
	 * MLA_List_Table inline edit item values
	 *
	 * Builds the Language dropdown and edit ttranslation links
	 * for the Quick and Bulk Edit forms.
	 *
	 * @since 1.00
	 *
	 * @param	array	$item_values parameter_name => parameter_value pairs
	 *
	 * @return	array	updated substitution parameter name => value pairs
	 */
	public static function mla_list_table_inline_values( $item_values ) {
		global $polylang;
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_values $item_values = ' . var_export( $item_values, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_values self::$language_columns = ' . var_export( self::$language_columns, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_values get_languages_list = ' . var_export( $polylang->filters_columns->model->get_languages_list(), true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_values curlang = ' . var_export( $polylang->filters_columns->curlang, true ), 0 );

		// Find the first "language" column slug
		foreach ( $polylang->filters_columns->model->get_languages_list() as $language) {
			if ( empty($polylang->filters_columns->curlang) || $language->slug != $polylang->filters_columns->curlang->slug) {
				$language_column = 'language_'.$language->slug;
				break;
			}
		}
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_values $language_column = ' . var_export( $language_column, true ), 0 );

		// do_action is required because the Polylang function uses "current_filter()" to compose its output
		ob_start();
		do_action( 'quick_edit_custom_box', $language_column, 'attachment' );
		$value = ob_get_clean();

		// Strip off <fieldset> and <div> tags around the <input> and <label> tags
		preg_match('/\<input|\<label/', $value, $match_start, PREG_OFFSET_CAPTURE );
		preg_match('/\<\/label[^\>]*\>/', $value, $match_end, PREG_OFFSET_CAPTURE );
		$item_values['custom_fields'] .= substr( $value, $match_start[0][1], ( $match_end[0][1] + strlen( $match_end[0][1] ) ) - $match_start[0][1] );

		// Add the Translate links to the Quick Edit values
		if ( array_key_exists( 'Quick Edit', $item_values ) ) {
			$actions = "<input name=\"inline_translations\" type=\"hidden\" value=\"\">\n";
			$actions .= "<input name=\"pll_quick_language\" type=\"hidden\" value=\"\">\n";
			$actions .= "<input name=\"pll_quick_id\" type=\"hidden\" value=\"\">\n";
			$actions .= "<label class=\"alignleft\" style=\"clear: both;\">\n<span class=\"title\">Translate</span>\n";
			$actions .= "<table class=\"pll-media-action-table\">\n";
			foreach ($polylang->model->get_languages_list() as $language) {
				$actions .= '<tr class = "pll-media-action-row-' . $language->slug . "\">\n";
				$actions .= '<td class = "pll-media-language-column"><span class = "pll-translation-flag">'. $language->flag . '</span>' . esc_html( $language->name ) . "</td>\n";
				$actions .= '<td class = "pll-media-action-column pll-media-action-column-' . $language->slug . '">';
				$actions .= sprintf( '<input type="hidden" name="media_tr_lang[%s]" value="" /><a href="#pll-quick-translate-edit" title="" class=""></a>', esc_attr($language->slug) );
				$actions .= "</td>\n";
				$actions .= "</tr>\n";
			}
			$actions .= "</table>\n</label>\n";
			$actions .= "<div class=\"pll-quick-translate-save\"><span class=\"spinner\" style=\"float: left;\"></span></div>\n";
			//error_log( 'MLAPolylangSupport::mla_list_table_inline_values $actions = ' . var_export( $actions, true ), 0 );
			$item_values['custom_fields'] .= $actions;
		}

		ob_start();
		do_action( 'bulk_edit_custom_box', $language_column, 'attachment' );
		$value = ob_get_clean();

		// Strip off <fieldset> and <div> tags around the <input> and <label> tags
		preg_match('/\<input|\<label/', $value, $match_start, PREG_OFFSET_CAPTURE );
		preg_match('/\<\/label[^\>]*\>/', $value, $match_end, PREG_OFFSET_CAPTURE );
		$item_values['bulk_custom_fields'] .= substr( $value, $match_start[0][1], ( $match_end[0][1] + strlen( $match_end[0][1] ) ) - $match_start[0][1] );

		return $item_values;
	} // mla_list_table_inline_values

	/**
	 * MLA_List_Table inline edit template
	 *
	 * This filter gives you a chance to modify and extend the template used
	 * for the Quick and Bulk Edit forms.
	 *
	 * @since 1.00
	 *
	 * @param	string	template used to generate the HTML markup
	 *
	 * @return	string	updated template
	 */
	public static function mla_list_table_inline_template( $item_template ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_template $item_template = ' . var_export( $item_template, true ), 0 );
		
		return $item_template;
	} // mla_list_table_inline_template

	/**
	 * MLA_List_Table inline edit parse
	 *
	 * @since 1.00
	 *
	 * Adds Bulk Translate form and the Language dropdown
	 * markup used for the Quick and Bulk Edit forms.
	 *
	 * @param	string	HTML markup returned by the template parser
	 * @param	string	template used to generate the HTML markup
	 * @param	array	parameter_name => parameter_value pairs
	 *
	 * @return	array	updated HTML markup for the Quick and Bulk Edit forms
	 */
	public static function mla_list_table_inline_parse( $html_markup, $item_template, $item_values ) {
		global $polylang, $post_ID;
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_parse $html_markup = ' . var_export( $html_markup, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_parse $item_template = ' . var_export( $item_template, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_parse $item_values = ' . var_export( $item_values, true ), 0 );
		
		/*
		 * Add the Quick and Bulk Translate Markup
		 */
		$page_template_array = MLAData::mla_load_template( plugin_dir_path( __FILE__ ) . 'mla-polylang-support.tpl', 'path' );
		if ( ! is_array( $page_template_array ) ) {
			//error_log( 'ERROR: mla-polylang-support.tpl path = ' . var_export( plugin_dir_path( __FILE__ ) . 'mla-polylang-support.tpl', true ), 0 );
			//error_log( 'ERROR: mla-polylang-support.tpl non-array result = ' . var_export( $page_template_array, true ), 0 );
			return $html_markup;
		}
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_parse $page_template_array = ' . var_export( $page_template_array, true ), 0 );
		
		$language_dropdowns = self::mla_list_table_inline_values( array( 'custom_fields' => '', 'bulk_custom_fields' => '' ) );
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_parse $language_dropdowns = ' . var_export( $language_dropdowns, true ), 0 );

		$quick_actions = "<table class=\"pll-media-action-table\">\n";
		$bulk_actions = "<table class=\"pll-media-action-table\">\n";
		foreach ($polylang->model->get_languages_list() as $language) {
			$page_values = array(
				'language_slug' => $language->slug,
				'language_flag' => $language->flag,
				'language_name' => $language->name,
			);
			$quick_actions .= MLAData::mla_parse_template( $page_template_array['quick_action'], $page_values );
			$bulk_actions .= MLAData::mla_parse_template( $page_template_array['bulk_action'], $page_values );
		}

		$quick_actions .= "</table>\n";

		$page_values = array(
			'language_slug' => 'all',
			'language_flag' => '&nbsp;',
			'language_name' => __( 'All Languages', 'mla-polylang-support' ),
		);
		$bulk_actions .= MLAData::mla_parse_template( $page_template_array['bulk_action'], $page_values );
		$bulk_actions .= "</table>\n";
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_parse $quick_actions = ' . var_export( $quick_actions, true ), 0 );

		$page_values = array(
			'colspan' => $item_values['colspan'],
			'Quick Translate' => __( 'Quick Translate', 'mla-polylang-support' ),
			'quick_translate_actions' => $quick_actions,
			'quick_translate_language' => $language_dropdowns['custom_fields'],
			'Cancel' => __( 'Cancel', 'mla-polylang-support' ),
			'Update' => __( 'Set Language', 'mla-polylang-support' ),
			'Bulk Translate' => __( 'Bulk Translate', 'mla-polylang-support' ),
			'Add or Modify' => __( 'Add or Modify Translation', 'mla-polylang-support' ),
			'Language' => __( 'Language', 'mla-polylang-support' ),
			'bulk_translate_actions' => $bulk_actions,
			'Options' => __( 'Options', 'mla-polylang-support' ),
			'Clear Filter-by' => __( 'Clear Filter-by', 'mla-polylang-support' ),
		);
		$parse_value = MLAData::mla_parse_template( $page_template_array['page'], $page_values );
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_parse $parse_value = ' . var_export( $parse_value, true ), 0 );

		return $html_markup . "\n" . $parse_value;
	} // mla_gallery_item_parse_filter

	/**
	 * Table language column definitions
	 *
	 * @since 1.00
	 *
	 * @var	array
	 */
	protected static $language_columns = NULL;

	/**
	 * Filter the MLA_List_Table columns
	 *
	 * Inserts the language columns just after the item thumbnail column
	 *
	 * @since 1.00
	 *
	 * @param	array	$columns An array of columns.
	 *					format: column_slug => Column Label
	 *
	 * @return	array	updated array of columns.
	 */
	public static function mla_list_table_get_columns( $columns ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_get_columns $columns = ' . var_export( $columns, true ), 0 );
		
		if ( is_null( self::$language_columns ) ) {
			global $polylang;
			self::$language_columns = $polylang->filters_columns->add_post_column( array() );
		}
		
		//error_log( 'MLAPolylangSupport::mla_list_table_get_columns self::$language_columns = ' . var_export( self::$language_columns, true ), 0 );

		if ( ! empty( self::$language_columns ) ) {
			$end = array_slice( $columns, 2) ;
			$columns = array_slice( $columns, 0, 2 );
			$columns = array_merge( $columns, self::$language_columns, $end );
			//error_log( 'MLAPolylangSupport::mla_list_table_get_columns updated $columns = ' . var_export( $columns, true ), 0 );
		}
		
		return $columns;
	} // mla_list_table_get_columns_filter

	/**
	 * Filter the MLA_List_Table hidden columns
	 *
	 * This MLA-specific filter gives you an opportunity to filter the hidden list table columns.
	 *
	 * @since 1.00
	 *
	 * @param	array	$hidden_columns An array of columns.
	 *					format: index => column_slug
	 *
	 * @return	array	updated array of columns.
	 */
	public static function mla_list_table_get_hidden_columns( $hidden_columns ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_get_hidden_columns $hidden_columns = ' . var_export( $hidden_columns, true ), 0 );
		return $hidden_columns;
	} // mla_list_table_get_hidden_columns_filter

	/**
	 * Filter the MLA_List_Table sortable columns
	 *
	 * This MLA-specific filter gives you an opportunity to filter the sortable list table
	 * columns; a good alternative to the 'manage_media_page_mla_menu_sortable_columns' filter.
	 *
	 * @since 1.00
	 *
	 * @param	array	$sortable_columns	An array of columns.
	 *										Format: 'column_slug' => 'orderby'
	 *										or 'column_slug' => array( 'orderby', true )
	 *
	 * The second format will make the initial sorting order be descending.
	 *
	 * @return	array	updated array of columns.
	 */
	public static function mla_list_table_get_sortable_columns( $sortable_columns ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_get_sortable_columns $sortable_columns = ' . var_export( $sortable_columns, true ), 0 );
		return $sortable_columns;
	} // mla_list_table_get_sortable_columns_filter

	/**
	 * Filter the MLA_List_Table bulk actions
	 *
	 * Adds the "Translate" action to the Bulk Actions list.
	 *
	 * @since 1.01
	 *
	 * @param	array	$actions	An array of bulk actions.
	 *								Format: 'slug' => 'Label'
	 *
	 * @return	array	updated array of actions.
	 */
	public static function mla_list_table_get_bulk_actions( $actions ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_get_bulk_actions $actions = ' . var_export( $actions, true ), 0 );

		$actions['pll-translate'] = __( 'Translate', 'mla-polylang-support' );
		return $actions;
	} // mla_list_table_get_bulk_actions

	/**
	 * Supply a column value if no column-specific function has been defined
	 *
	 * Fills in the Language columns with the item's translation status values.
	 *
	 * @since 1.00
	 *
	 * @param	string	NULL, indicating no default content
	 * @param	array	A singular item (one full row's worth of data)
	 * @param	array	The name/slug of the column to be processed
	 * @return	string	Text or HTML to be placed inside the column
	 */
	public static function mla_list_table_column_default( $content, $item, $column_name ) {
		//error_log( "MLAPolylangSupport::mla_list_table_column_default ({$column_name}) \$item = " . var_export( $item, true ), 0 );
		
		if ( is_array( self::$language_columns ) && array_key_exists( $column_name, self::$language_columns ) ) {
			global $polylang;
			
			// Polylang post_column() function applies this test for 'inline-save' before updating "language"
			$inline = defined('DOING_AJAX') && isset($_POST['inline_lang_choice']) && in_array( $_REQUEST['action'], array( self::MLA_PLL_QUICK_TRANSLATE, MLA::JAVASCRIPT_INLINE_EDIT_SLUG ) );
		
			if ( $inline ) {
				$save_action = $_REQUEST['action'];
				$_REQUEST['action'] = 'inline-save';
			}
			
			// post_column echoes the content and returns NULL
			$polylang->filters_columns->post_column( $column_name, $item->ID );
			$content = '';

			if ( $inline ) {
				$_REQUEST['action'] = $save_action;
			}
		}
		
		//error_log( "MLAPolylangSupport::mla_list_table_column_default ({$column_name}) updated \$content = " . var_export( $content, true ), 0 );
		return $content;
	} // mla_list_table_column_default_filter

	/**
	 * Data selection parameters for custom views
	 *
	 * @since 1.04
	 *
	 * @var	array
	 */
	private static $list_table_parameters = array(
		'total_items' => NULL,
		'per_page' => NULL,
		'current_page' => NULL,
	);
	
	/**
	 * Filter the "sticky" submenu URL parameters
	 *
	 * Maintains the pll_view and list of Bulk Translate items in the URLs for paging through the results.
	 *
	 * @since 1.00
	 *
	 * @param	array	$submenu_arguments	Current view, pagination and sort parameters.
	 * @param	object	$include_filters	True to include "filter-by" parameters, e.g., year/month dropdown.
	 *
	 * @return	array	updated submenu_arguments.
	 */
	public static function mla_list_table_submenu_arguments( $submenu_arguments, $include_filters ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_submenu_arguments $submenu_arguments = ' . var_export( $submenu_arguments, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_submenu_arguments $include_filters = ' . var_export( $include_filters, true ), 0 );

		if ( isset( $_REQUEST['pll_view'] ) ) {
			$submenu_arguments['pll_view'] = $_REQUEST['pll_view'];
		}
		
		if ( $include_filters && ( ! empty( self::$bulk_action_includes ) ) ) {
			$submenu_arguments['ids'] = implode( ',', self::$bulk_action_includes );
			$submenu_arguments['heading_suffix'] = __( 'Bulk Translations', 'mla-polylang-support' );
		}
		
		return $submenu_arguments;
	} // mla_list_table_submenu_arguments

	/**
	 * Filter the pagination parameters for prepare_items()
	 *
	 * Records the pagination parameters for use with custom table views, e.g., "attached".
	 *
	 * @since 1.00
	 *
	 * @param	array	$pagination		Contains 'per_page', 'current_page'.
	 * @param	object	$mla_list_table	The MLA_List_Table object, passed by reference.
	 *
	 * @return	array	updated pagination array.
	 */
	public static function mla_list_table_prepare_items_pagination( $pagination, $mla_list_table ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_prepare_items_pagination $pagination = ' . var_export( $pagination, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_prepare_items_pagination $mla_list_table->get_pagenum() = ' . var_export( $mla_list_table->get_pagenum(), true ), 0 );
		
		self::$list_table_parameters = array_merge( self::$list_table_parameters, $pagination );
//error_log( 'MLAPolylangSupport::mla_list_table_prepare_items_pagination self::$list_table_parameters = ' . var_export( self::$list_table_parameters, true ), 0 );

		return $pagination;
	} // mla_list_table_prepare_items_pagination_filter

	/**
	 * Filter the total items count for prepare_items()
	 *
	 * A convenient place to add the query argument required for the "attached" custom view.
	 *
	 * @since 1.00
	 *
	 * @param	integer	$total_items	NULL, indicating no substitution.
	 * @param	object	$mla_list_table	The MLA_List_Table object, passed by reference.
	 *
	 * @return	integer	updated total_items.
	 */
	public static function mla_list_table_prepare_items_total_items( $total_items, $mla_list_table ) {
		global $wpdb;
		
		if ( isset( $_REQUEST['pll-bulk-translate'] ) ) {
			$_REQUEST['ids'] = self::$bulk_action_includes;
			// $_REQUEST['heading_suffix'] = __( 'Bulk Translations', 'mla-polylang-support' );
		}
		
		if ( isset( $_REQUEST['pll_view'] ) ) {
			switch( $_REQUEST['pll_view'] ) {
				case 'attached':
					$_REQUEST['detached'] = '0';
					break;
				default:
			} // pll_view
		}

		//error_log( 'MLAPolylangSupport::mla_list_table_prepare_items_total_items returning $total_items = ' . var_export( $total_items, true ), 0 );
		return $total_items;
	} // mla_list_table_prepare_items_total_items_filter
	
	/**
	 * Filter the items returned by prepare_items()
	 *
	 * This filter gives you an opportunity to substitute your own items array
	 * in place of the default prepare_items database query.
	 *
	 * @since 1.00
	 *
	 * @param	array	$items			NULL, indicating no substitution.
	 * @param	object	$mla_list_table	The MLA_List_Table object, passed by reference.
	 *
	 * @return	array	updated $items array.
	 */
	public static function mla_list_table_prepare_items_the_items( $items, $mla_list_table ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_prepare_items_the_items $items = ' . var_export( $items, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_prepare_items_the_items total_items = ' . var_export( $mla_list_table->get_pagination_arg('total_items'), true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_prepare_items_the_items total_pages = ' . var_export( $mla_list_table->get_pagination_arg('total_pages'), true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_prepare_items_the_items per_page = ' . var_export( $mla_list_table->get_pagination_arg('per_page'), true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_prepare_items_the_items page = ' . var_export( $mla_list_table->get_pagination_arg('page'), true ), 0 );
		return $items;
	} // mla_list_table_prepare_items_the_items_filter
	
	/**
	 * Inspect or modify the results of prepare_items()
	 *
	 * This action gives you an opportunity to record or modify the results of the
	 * prepare_items database query. 
	 *
	 * @since 1.00
	 *
	 * @param	object	$mla_list_table	The MLA_List_Table object, passed by reference.
	 *
	 * @return	void	actions do not return anything.
	 */
	public static function mla_list_table_prepare_items( $mla_list_table ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_prepare_items $mla_list_table->get_pagenum() = ' . var_export( $mla_list_table->get_pagenum(), true ), 0 );
		return $mla_list_table;
	} // mla_list_table_prepare_items
	
	/**
	 * Filter the list of item "Rollover" actions
	 *
	 * Adds "Quick Translate" to the list of item-level "Rollover" actions.
	 *
	 * @since 1.00
	 *
	 * @param	array	$actions	The list of item "Rollover" actions.
	 * @param	object	$item		The current Media Library item.
	 * @param	string	$column		The List Table column slug.
	 *
	 * @return	array	updated		"Rollover" actions.
	 */
	public static function mla_list_table_build_rollover_actions( $actions, $item, $column ) {
		//error_log( "MLAPolylangSupport::mla_list_table_build_rollover_actions ({$column}) \$actions = " . var_export( $actions, true ), 0 );
		//error_log( "MLAPolylangSupport::mla_list_table_build_rollover_actions ({$column}) \$item = " . var_export( $item, true ), 0 );
		
		/*
		 * Add the Quick Translate action
		 */
		$actions['translate hide-if-no-js'] = '<a class="inlineTranslate" href="#" title="' . __( 'Translate this item inline', 'mla-polylang-support' ) . '">' . __( 'Quick Translate', 'mla-polylang-support' ) . '</a>';

		return $actions;
	} // mla_list_table_build_rollover_actions_filter

	/**
	 * Define the fields for inline (Quick) editing
	 *
	 * Adds Language dropdown and Quick Translate links.
	 *
	 * @since 1.00
	 *
	 * @param	array	$fields	The field names for inline data.
	 *
	 * @return	string	updated fields for inline data.
	 */
	public static function mla_list_table_inline_fields( $fields ) {
		//error_log( 'MLAPolylangSupport::mla_list_table_inline_fields $fields = ' . var_export( $fields, true ), 0 );
		$fields[] = 'old_lang';
		$fields[] = 'inline_lang_choice';
		$fields[] = 'inline_translations';
		
		return $fields;
	} // mla_list_table_inline_fields

	/**
	 * Filter the data for inline (Quick and Bulk) editing
	 *
	 * Adds item-specific translations data for the JS quick and bulk edit functions.
	 *
	 * @since 1.00
	 *
	 * @param	string	$inline_data	The HTML markup for inline data.
	 * @param	object	$item			The current Media Library item.
	 *
	 * @return	string	updated HTML markup for inline data.
	 */
	public static function mla_list_table_build_inline_data( $inline_data, $item ) {
		global $polylang;
		//error_log( 'MLAPolylangSupport::mla_list_table_build_inline_data $inline_data = ' . var_export( $inline_data, true ), 0 );
		//error_log( 'MLAPolylangSupport::mla_list_table_build_inline_data $item = ' . var_export( $item, true ), 0 );

		$item_id = $item->ID;
		$old_lang = $polylang->model->get_post_language( $item_id );
		//error_log( "MLAPolylangSupport::mla_list_table_build_inline_data ({$item_id}) \$old_lang = " . var_export( $old_lang, true ), 0 );
		if ( isset( $old_lang->slug ) ) {
			$old_lang = $old_lang->slug;
		} else {
			$old_lang = '';
		}

		$translations = $polylang->model->get_translations( 'post', $item_id );
		//error_log( "MLAPolylangSupport::mla_list_table_build_inline_data ({$item_id}) \$translations = " . var_export( $translations, true ), 0 );
		$translations[ $old_lang ] = $item_id;
		$translations = json_encode( $translations );
		//error_log( "MLAPolylangSupport::mla_list_table_build_inline_data ({$item_id}) JSON \$translations = " . var_export( $translations, true ), 0 );

		$inline_data .= "\n\t\t<div class=\"old_lang\">{$old_lang}</div>";
		$inline_data .= "\n\t\t<div class=\"inline_lang_choice\">{$old_lang}</div>";
		$inline_data .= "\n\t\t<div class=\"inline_translations\">{$translations}</div>";
		return $inline_data;
	} // mla_list_table_build_inline_data_filter

	/**
	 * Views for the "upload" page when WPML is active
	 *
	 * This filter is hooked by WPML Media in wpml-media.class.php, and is only
	 * applied when WPML is active.
	 *
	 * @since 1.00
	 *
	 * @param	array	$views An array of available list table views.
	 *
	 * @return	array	updated list table views.
	 */
	public static function views_upload( $views ) {
		//error_log( 'MLAPolylangSupport::views_upload $views = ' . var_export( $views, true ), 0 );
		return $views;
	} // views_upload_filter

	/**
	 * Save the query arguments
	 *
	 * @since 1.00
	 *
	 * @var	array
	 */
	private static $all_query_parameters = array();

	/**
	 * MLA Tag Cloud Query Arguments
	 *
	 * Saves [mla_tag_cloud] query parameters for use in MLAPolylangSupport::mla_get_terms_clauses.
	 *
	 * @since 1.00
	 * @uses MLAPolylangSupport::$all_query_parameters
	 *
	 * @param	array	shortcode arguments merged with attachment selection defaults, so every possible parameter is present
	 *
	 * @return	array	updated attachment query arguments
	 */
	public static function mla_get_terms_query_arguments( $all_query_parameters ) {
		//error_log( 'MLAPolylangSupport::mla_get_terms_query_arguments_filter $all_query_parameters = ' . var_export( $all_query_parameters, true ), 0 );

		self::$all_query_parameters = $all_query_parameters;
		return $all_query_parameters;
	} // mla_get_terms_query_arguments

	/**
	 * MLA Tag Cloud Query Clauses
	 *
	 * Adds language-specific clauses to filter the cloud terms.
	 *
	 * @since 1.01
	 *
	 * @param	array	SQL clauses ( 'fields', 'join', 'where', 'order', 'orderby', 'limits' )
	 *
	 * @return	array	updated SQL clauses
	 */
	public static function mla_get_terms_clauses( $clauses ) {
		global $polylang;
		//error_log( 'MLAPolylangSupport::mla_get_terms_clauses $clauses = ' . var_export( $clauses, true ), 0 );
		
		$clauses = $polylang->filters->terms_clauses($clauses, self::$all_query_parameters['taxonomy'], self::$all_query_parameters );

		return $clauses;
	} // mla_get_terms_clauses
} // Class MLAPolylangSupport

/*
 * Install the filters at an early opportunity
 */
add_action('init', 'MLAPolylangSupport::initialize');
?>